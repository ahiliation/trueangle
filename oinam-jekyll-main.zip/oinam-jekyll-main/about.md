---
layout: page
title: About
permalink: /about/
---

This is an example page that uses the `page` layout.

Visit the [Homepage]({{ site.baseurl | prepend: site.url }}/) for documentation on installation, setup, how-tos, features, and more about this Jekyll theme.

---

Email us at [hi@oinam.com](mailto:hi@oinam.com?subject=Oinam Jekyll).\
Find us at
[oinam.com](https://oinam.com),
[Twitter](https://twitter.com/oinam),
[Instagram](https://www.instagram.com/oinam/).