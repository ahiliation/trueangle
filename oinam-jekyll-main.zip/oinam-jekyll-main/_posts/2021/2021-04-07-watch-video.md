---
layout: post
title: The Title of the Page but stripped
---

# Let's Watch some Videos

{% include video source="youtube" id="qaF6dPiJ-NM" %}

This is a responsive video embed. In your post, use the tag
{% raw  %}
`{% include video source="youtube" id="qaF6dPiJ-NM" %}`
{% endraw %}
where `source` can be `youtube`, `vimeo`, or `google-drive` and the `id` is the specific code you find in the YouTube Video URL such as `https://www.youtube.com/watch?v=qaF6dPiJ-NM` (the one after `?v`).