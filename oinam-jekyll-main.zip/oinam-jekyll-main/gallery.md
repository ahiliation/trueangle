---
layout: page
title: Gallery
permalink: /gallery/
---

A page with just a photos gallery. You can remove the title above in the `front matter` and this text too.

<div class="gallery content-full">
  <a href="https://story.oinam.com"><img src="https://picsum.photos/600/400/"></a>
  <img src="https://picsum.photos/800/600/">
  <img src="https://picsum.photos/480/320/">
  <img src="https://picsum.photos/800/600/">
  <a href="https://oinam.com"><img src="https://picsum.photos/600/400/"></a>
  <img src="https://picsum.photos/400/480/">
  <img src="https://picsum.photos/800/600/">
  <img src="https://picsum.photos/480/320/">
  <img src="https://picsum.photos/600/300/">
  <img src="https://picsum.photos/480/320/">
  <img src="https://picsum.photos/800/600/">
  <a href="https://oinam.com"><img src="https://picsum.photos/600/400/"></a>
  <img src="https://picsum.photos/400/480/">
  <img src="https://picsum.photos/800/600/">
  <img src="https://picsum.photos/600/300/">
  <img src="https://picsum.photos/480/320/">
</div>